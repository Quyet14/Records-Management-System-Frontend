/* Report endpoints enforce the current department on the server. Never fall back to global document search. */
(function (root) {
  'use strict';
  const identity = value => String(typeof value === 'object' ? value?.id || value?._id || '' : value || '');
  function scope(user) {
    if (user?.role !== 'department_head') throw new Error('Chỉ Trưởng khoa được xem báo cáo khoa.');
    const id = identity(user.departmentId || user.department);
    if (!id) throw new Error('Tài khoản chưa được gán khoa. Vui lòng liên hệ quản trị viên.');
    return id;
  }
  function number(value) {
    if (value === null || value === '' || !Number.isFinite(Number(value)) || Number(value) < 0)
      throw new Error('Số liệu báo cáo từ máy chủ không hợp lệ.');
    return Number(value);
  }
  function array(value) {
    if (!Array.isArray(value)) throw new Error('Danh sách báo cáo từ máy chủ không hợp lệ.');
    return value;
  }
  function page(value) {
    array(value?.data);
    if (!Number.isInteger(value.total) || value.total < 0 || !Number.isInteger(value.page) || value.page < 1
      || !Number.isInteger(value.limit) || value.limit < 1 || value.limit > 100)
      throw new Error('Dữ liệu phân trang báo cáo không hợp lệ.');
    return value;
  }
  function yearValue(value) {
    const year = Number(value);
    if (!Number.isInteger(year) || year < 1900 || year > 9999) throw new Error('Năm phải là số nguyên từ 1900 đến 9999.');
    return year;
  }
  function overview(value) {
    ['totalDocuments', 'totalUsers', 'storedSizeBytes'].forEach(key => number(value?.[key]));
    array(value.byStatus).forEach(row => number(row.count));
    return value;
  }
  async function loadStats(user, get, year) {
    scope(user);
    const targetYear = yearValue(year);
    const [summary, types, monthly] = await Promise.all([
      get('/stats/overview'), get('/stats/by-document-type'), get('/stats/by-year?year=' + targetYear)
    ]);
    overview(summary);
    array(types?.byType).forEach(row => number(row.totalDocuments));
    if (monthly?.year !== targetYear || array(monthly?.monthly).length !== 12
      || monthly.monthly.some((row, index) => row.month !== index + 1)) throw new Error('Báo cáo tháng từ máy chủ không hợp lệ.');
    monthly.monthly.forEach(row => { number(row.totalDocuments); number(row.totalBytes); });
    return { summary, types, monthly };
  }
  async function loadMonitor(user, get, pages, action = '') {
    scope(user);
    if (!['', 'approve', 'reject', 'auto-approve (private)'].includes(action)) throw new Error('Bộ lọc lịch sử không hợp lệ.');
    const query = kind => {
      const current = pages[kind] || 1;
      if (!Number.isInteger(current) || current < 1 || current > 1000000) throw new Error('Trang báo cáo không hợp lệ.');
      return new URLSearchParams({ page: current, limit: 20 });
    };
    const historyQuery = query('history');
    if (action) historyQuery.set('action', action);
    const [summary, missing, review, progress, expiring, history] = await Promise.all([
      get('/stats/overview'), get('/system/missing-checksums?' + query('checksums')),
      get('/retention/pending-review?' + query('review')), get('/retention/review-summary'),
      get('/retention/expiring?days=365'), get('/system/audit-logs?' + historyQuery)
    ]);
    overview(summary); page(missing); page(review); page(history); array(expiring);
    ['totalOldDocuments', 'completed', 'remaining', 'completionRate'].forEach(key => number(progress?.[key]));
    return { summary, missing, review, progress, expiring, history };
  }
  const reports = { scope, loadStats, loadMonitor };
  if (typeof module !== 'undefined' && module.exports) { module.exports = reports; return; }
  root.DepartmentReports = reports;

  const $ = id => document.getElementById(id);
  const mode = document.querySelector('[data-department-report]')?.dataset.departmentReport;
  if (!mode) return;
  let serial = 0;
  const pages = { checksums: 1, review: 1, history: 1 };
  const labels = { stored: 'Đã lưu kho', approved: 'Đã duyệt', pending: 'Chờ duyệt', rejected: 'Từ chối', destroyed: 'Đã hủy' };
  const actions = { approve: 'Duyệt', reject: 'Từ chối', 'auto-approve (private)': 'Tự động duyệt (riêng tư)' };
  const date = value => value ? fmtDate(value) : '—';
  function table(headings, rows) {
    return rows.length ? `<div class="table-wrap"><table><thead><tr>${headings.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
      : '<p class="report-empty">Chưa có dữ liệu phù hợp trong khoa.</p>';
  }
  function cards(items) {
    return items.map(([label, value]) => `<div class="stat-card"><span class="stat-label">${esc(label)}</span><span class="stat-value">${esc(value)}</span></div>`).join('');
  }
  function bars(rows) {
    const max = Math.max(1, ...rows.map(row => number(row.count)));
    return rows.map(row => `<div class="report-bar"><span>${esc(row.label)}</span><meter min="0" max="${max}" value="${number(row.count)}">${number(row.count)}</meter><strong>${number(row.count)}</strong></div>`).join('')
      || '<p class="report-empty">Chưa có dữ liệu phù hợp trong khoa.</p>';
  }
  function pager(kind, payload) {
    const pages = Math.max(1, Math.ceil(payload.total / payload.limit));
    return `<div class="report-toolbar report-pagination"><button type="button" class="btn btn-ghost btn-sm" data-report-page="${kind}" data-page="${payload.page - 1}" ${payload.page <= 1 ? 'disabled' : ''}>Trước</button><span>Trang ${payload.page}/${pages} · ${payload.total} kết quả</span><button type="button" class="btn btn-ghost btn-sm" data-report-page="${kind}" data-page="${payload.page + 1}" ${payload.page >= pages ? 'disabled' : ''}>Sau</button></div>`;
  }
  function renderStats(data) {
    const { summary, types, monthly } = data;
    const count = status => summary.byStatus.find(row => row.status === status)?.count || 0;
    $('report-summary').innerHTML = cards([
      ['Tổng hồ sơ hiện có', summary.totalDocuments], ['Thành viên khoa', summary.totalUsers],
      ['Đã lưu kho', count('stored')], ['Đã duyệt', count('approved')], ['Chờ duyệt', count('pending')],
      ['Từ chối', count('rejected')], ['Dung lượng đã lưu kho', fmtSize(summary.storedSizeBytes)]
    ]);
    $('report-status').innerHTML = bars(summary.byStatus.map(row => ({ label: labels[row.status] || row.status, count: row.count })));
    $('report-types').innerHTML = bars(types.byType.map(row => ({ label: row.typeName || 'Chưa phân loại', count: row.totalDocuments })));
    $('report-months').innerHTML = table(['Tháng', 'Hồ sơ', 'Dung lượng'], monthly.monthly.map(row => `<tr><td>Tháng ${row.month}</td><td>${number(row.totalDocuments)}</td><td>${esc(fmtSize(row.totalBytes))}</td></tr>`));
  }
  function renderMonitor(data) {
    const { summary, missing, review, progress, expiring, history } = data;
    $('report-summary').innerHTML = cards([
      ['Dung lượng đã lưu kho', fmtSize(summary.storedSizeBytes)], ['Thiếu checksum', missing.total],
      ['Chờ chỉnh lý', review.total], ['Sắp hết hạn trong 1 năm', expiring.length]
    ]);
    $('report-checksums').innerHTML = table(['Hồ sơ thiếu checksum', 'Mã hồ sơ', 'Trạng thái', 'Ngày tải'], missing.data.map(doc => `<tr><td>${esc(doc.title)}</td><td>${esc(doc.documentNumber || doc.id)}</td><td>${esc(labels[doc.status] || doc.status)}</td><td>${esc(date(doc.createdAt))}</td></tr>`)) + pager('checksums', missing);
    $('report-review').innerHTML = `<p class="report-note">Đã chỉnh lý ${number(progress.completed)}/${number(progress.totalOldDocuments)} hồ sơ (${number(progress.completionRate)}%). Còn ${number(progress.remaining)} hồ sơ. Hạn hoàn thành: ${esc(date(progress.deadline))}.</p>`
      + table(['Hồ sơ cần chỉnh lý', 'Loại hồ sơ', 'Ngày hình thành'], review.data.map(doc => `<tr><td>${esc(doc.title)}</td><td>${esc(doc.documentType || '—')}</td><td>${esc(date(doc.documentDate))}</td></tr>`)) + pager('review', review);
    $('report-expiry').innerHTML = table(['Hồ sơ', 'Loại hồ sơ', 'Hạn bảo quản', 'Số ngày còn lại'], expiring.map(doc => `<tr><td>${esc(doc.title)}</td><td>${esc(doc.documentType || '—')}</td><td>${esc(date(doc.expiresAt))}</td><td>${esc(doc.daysRemaining)}</td></tr>`));
    $('report-history').innerHTML = table(['Thời gian', 'Hồ sơ', 'Hành động', 'Người xử lý', 'Lý do'], history.data.map(log => `<tr><td>${esc(log.createdAt ? new Date(log.createdAt).toLocaleString('vi-VN') : '—')}</td><td>${esc(log.documentTitle || log.documentId || '—')}</td><td>${esc(actions[log.action] || log.action)}</td><td>${esc(log.actorName || 'Không ghi nhận')}</td><td>${esc(log.metadata?.reason || '—')}</td></tr>`)) + pager('history', history);
  }
  function clear() {
    $('report-summary').innerHTML = '';
    document.querySelectorAll('[data-report-content]').forEach(el => { el.innerHTML = ''; });
  }
  async function reload() {
    const ticket = ++serial;
    clear();
    $('report-message').textContent = 'Đang tải báo cáo khoa…';
    $('report-refresh').disabled = true;
    try {
      const user = await Auth.requireDeptHead();
      const id = scope(user);
      $('report-department').textContent = `${mode === 'stats' ? 'Thống kê' : 'Giám sát'} — ${user.department?.name || 'Khoa của tôi'}`;
      const get = path => api.get(path);
      const data = mode === 'stats' ? await loadStats(user, get, $('report-year').value)
        : await loadMonitor(user, get, pages, $('report-history-filter').value);
      if (ticket !== serial) return;
      if (scope(Auth.getUser()) !== id) throw new Error('Khoa của tài khoản đã thay đổi. Vui lòng tải lại trang.');
      mode === 'stats' ? renderStats(data) : renderMonitor(data);
      $('report-message').textContent = `Dữ liệu thuộc khoa của bạn. Cập nhật: ${new Date().toLocaleString('vi-VN')}.`;
    } catch (error) {
      if (ticket !== serial) return;
      clear();
      $('report-message').textContent = error.status === 403
        ? `Không được phép xem báo cáo khoa. ${error.message || 'Kiểm tra quyền Trưởng khoa và khoa được gán cho tài khoản.'}`
        : error.message || 'Không tải được báo cáo. Bấm Tải lại để thử lại.';
    } finally { if (ticket === serial) $('report-refresh').disabled = false; }
  }
  $('report-year')?.addEventListener('change', reload);
  $('report-history-filter')?.addEventListener('change', () => { pages.history = 1; reload(); });
  $('report-refresh').addEventListener('click', reload);
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-report-page]');
    if (!button || button.disabled || $('report-refresh').disabled) return;
    const kind = button.dataset.reportPage;
    if (!Object.hasOwn(pages, kind)) return;
    pages[kind] = Number(button.dataset.page);
    reload();
  });
  if ($('report-year')) $('report-year').value = new Date().getFullYear();
  root.addEventListener('lths:session', () => { clear(); });
  onPageReady(reload);
})(typeof window !== 'undefined' ? window : globalThis);
